extends Node3D

# Fully procedural offline FPS vertical slice. No external assets required.
const WALK_SPEED := 6.5
const RUN_SPEED := 10.0
const JUMP_SPEED := 8.0
const MOUSE_SENS := 0.0025
const TOUCH_SENS := 0.0035
var player: CharacterBody3D
var head: Node3D
var camera: Camera3D
var gun: MeshInstance3D
var hud: Label
var status: Label
var joy_base: Control
var joy_knob: Control
var fire_button: Button
var jump_button: Button
var sprint_button: Button
var joystick_id := -1
var look_id := -1
var joystick_vector := Vector2.ZERO
var touch_last := Vector2.ZERO
var fire_held := false
var sprint_held := false
var cooldown := 0.0
var score := 0
var experience_points := 0
var reward_coins := 0
var patrol_clock := 0.0
var targets: Array[StaticBody3D] = []
var recoil := 0.0
var health := 100
var ammo := 30
var reserve_ammo := 150
var magazine_size := 30
var reload_timer := 0.0
var aiming := false
var hit_marker_timer := 0.0
var hit_marker: Label
var reload_button: Button
var aim_button: Button
var shot_flash: OmniLight3D
var mission_started := false
var intro_overlay: Control


func _ready() -> void:
 _create_world()
 _create_egyptian_life()
 _create_player()
 _create_targets()
 _create_ui()
 _create_muzzle_flash()
 _create_hero_intro()
 Input.mouse_mode = Input.MOUSE_MODE_CAPTURED if not OS.has_feature("mobile") else Input.MOUSE_MODE_VISIBLE

func material(color: Color, rough: float = 0.95) -> StandardMaterial3D:
 var m := StandardMaterial3D.new()
 m.albedo_color = color
 m.roughness = rough
 return m

func box(parent: Node3D, pos: Vector3, size: Vector3, mat: Material, solid := true) -> Node3D:
 var root: Node3D = StaticBody3D.new() if solid else Node3D.new()
 parent.add_child(root)
 root.position = pos
 var mesh := MeshInstance3D.new()
 var shape := BoxMesh.new()
 shape.size = size
 mesh.mesh = shape
 mesh.material_override = mat
 root.add_child(mesh)
 if solid:
  var collider := CollisionShape3D.new()
  var c := BoxShape3D.new()
  c.size = size
  collider.shape = c
  root.add_child(collider)
 return root

func _create_world() -> void:
 var env := WorldEnvironment.new()
 add_child(env)
 var e := Environment.new()
 e.background_mode = Environment.BG_COLOR
 e.background_color = Color(0.54, 0.69, 0.77)
 e.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
 e.ambient_light_color = Color(0.73, 0.70, 0.62)
 e.ambient_light_energy = 0.7
 e.tonemap_mode = Environment.TONE_MAPPER_FILMIC
 env.environment = e
 var sun := DirectionalLight3D.new()
 sun.rotation_degrees = Vector3(-48, -30, 0)
 sun.light_energy = 1.5
 sun.shadow_enabled = true
 add_child(sun)
 var sand := material(Color(0.69, 0.56, 0.37))
 var stone := material(Color(0.52, 0.44, 0.33))
 var stone2 := material(Color(0.62, 0.54, 0.40))
 var dark := material(Color(0.24, 0.24, 0.21))
 box(self, Vector3(0,-0.6,0), Vector3(180,1,180), sand)
 var rng := RandomNumberGenerator.new()
 rng.seed = 1942
 for i in range(75):
  var x := rng.randf_range(-76,76)
  var z := rng.randf_range(-76,76)
  if absf(x) < 10 and absf(z) < 10: continue
  var h := rng.randf_range(1.4,5.5)
  box(self, Vector3(x,h/2.0,z), Vector3(rng.randf_range(2.0,6.0),h,rng.randf_range(2.0,6.0)), stone if i%2 == 0 else stone2)
 for i in range(18):
  var z := -55.0 + i*6.0
  box(self, Vector3(-14,1.2,z), Vector3(1.0,2.4,4.5), stone)
 for i in range(10):
  var x := -36.0 + i*8.0
  box(self, Vector3(x,0.6,-25), Vector3(3.5,1.2,1.8), dark)
 # Broken desert walls and a clear central combat lane.
 box(self, Vector3(17,1.7,-10), Vector3(14,3.4,1.4), stone2)
 box(self, Vector3(23,1.7,-20), Vector3(1.4,3.4,18), stone2)
 box(self, Vector3(-18,1.3,8), Vector3(11,2.6,1.2), stone)

func _create_player() -> void:
 player = CharacterBody3D.new()
 player.name = "Player"
 player.position = Vector3(0,2,12)
 add_child(player)
 var collider := CollisionShape3D.new()
 var cap := CapsuleShape3D.new()
 cap.radius = 0.4
 cap.height = 1.8
 collider.position.y = 0.9
 collider.shape = cap
 player.add_child(collider)
 head = Node3D.new()
 head.position.y = 1.62
 player.add_child(head)
 camera = Camera3D.new()
 camera.current = true
 camera.fov = 78
 head.add_child(camera)
 gun = MeshInstance3D.new()
 var weapon := BoxMesh.new()
 weapon.size = Vector3(0.18,0.22,0.85)
 gun.mesh = weapon
 gun.material_override = material(Color(0.17,0.18,0.17),0.45)
 gun.position = Vector3(0.33,-0.32,-0.75)
 camera.add_child(gun)
 var barrel := MeshInstance3D.new()
 var cylinder := CylinderMesh.new()
 cylinder.top_radius = 0.045
 cylinder.bottom_radius = 0.045
 cylinder.height = 0.65
 barrel.mesh = cylinder
 barrel.rotation_degrees.x = 90
 barrel.position = Vector3(0,-0.015,-0.57)
 barrel.material_override = material(Color(0.08,0.08,0.09),0.4)
 gun.add_child(barrel)

func _create_muzzle_flash() -> void:
 shot_flash = OmniLight3D.new()
 shot_flash.light_color = Color(1.0, 0.66, 0.28)
 shot_flash.light_energy = 0.0
 shot_flash.omni_range = 4.0
 camera.add_child(shot_flash)
 shot_flash.position = Vector3(0.25,-0.22,-0.9)

func _reload() -> void:
 if reload_timer > 0.0 or ammo >= magazine_size or reserve_ammo <= 0: return
 reload_timer = 1.8

func _finish_reload() -> void:
 var count := mini(magazine_size - ammo, reserve_ammo)
 ammo += count
 reserve_ammo -= count

func _toggle_aim() -> void:
 aiming = not aiming

func _create_targets() -> void:
 var olive := material(Color(0.28,0.32,0.23))
 var helmet := material(Color(0.17,0.22,0.17))
 for i in range(12):
  var angle := i*TAU/12.0
  var radius := 20.0 + float(i%4)*7.0
  var p := Vector3(sin(angle)*radius,0,cos(angle)*radius)
  var body := box(self, p+Vector3(0,1.0,0),Vector3(0.75,1.7,0.5),olive) as StaticBody3D
  body.set_meta("target",true)
  body.set_meta("hit_points",3)
  body.set_meta("patrol_origin",body.position)
  body.set_meta("patrol_phase",float(i)*0.9)
  body.set_meta("patrol_axis",Vector3(1,0,0) if i%2 == 0 else Vector3(0,0,1))
  targets.append(body)
  box(body, Vector3(0,1.15,0), Vector3(0.85,0.4,0.65),helmet,false)

func _create_ui() -> void:
 var layer := CanvasLayer.new()
 add_child(layer)
 var root := Control.new()
 root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
 root.mouse_filter = Control.MOUSE_FILTER_PASS
 layer.add_child(root)
 hud = Label.new()
 hud.text = "WAR FRONT: EGYPT 1942  |  ALAMEIN PROTOTYPE"
 hud.position = Vector2(20,14)
 hud.add_theme_font_size_override("font_size",24)
 root.add_child(hud)
 status = Label.new()
 status.position = Vector2(20,50)
 status.add_theme_font_size_override("font_size",21)
 root.add_child(status)
 var cross := Label.new()
 cross.text = "+"
 cross.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
 cross.position = Vector2(-8,-18)
 cross.add_theme_font_size_override("font_size",38)
 cross.mouse_filter = Control.MOUSE_FILTER_IGNORE
 root.add_child(cross)
 hit_marker = Label.new()
 hit_marker.text = "X"
 hit_marker.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
 hit_marker.position = Vector2(-9,-18)
 hit_marker.add_theme_font_size_override("font_size",34)
 hit_marker.add_theme_color_override("font_color",Color(1.0,0.25,0.16))
 hit_marker.visible = false
 hit_marker.mouse_filter = Control.MOUSE_FILTER_IGNORE
 root.add_child(hit_marker)
 joy_base = ColorRect.new()
 joy_base.color = Color(0.9,0.9,0.9,0.16)
 joy_base.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_LEFT)
 joy_base.position = Vector2(45,-205)
 joy_base.size = Vector2(150,150)
 joy_base.mouse_filter = Control.MOUSE_FILTER_IGNORE
 root.add_child(joy_base)
 joy_knob = ColorRect.new()
 joy_knob.color = Color(1,1,1,0.43)
 joy_knob.position = Vector2(55,55)
 joy_knob.size = Vector2(40,40)
 joy_knob.mouse_filter = Control.MOUSE_FILTER_IGNORE
 joy_base.add_child(joy_knob)
 fire_button = _button(root,"FIRE",Vector2(-155,-185),Vector2(125,125))
 fire_button.button_down.connect(func(): fire_held = true)
 fire_button.button_up.connect(func(): fire_held = false)
 jump_button = _button(root,"JUMP",Vector2(-290,-110),Vector2(115,70))
 jump_button.pressed.connect(_jump)
 sprint_button = _button(root,"RUN",Vector2(-430,-110),Vector2(115,70))
 sprint_button.button_down.connect(func(): sprint_held = true)
 sprint_button.button_up.connect(func(): sprint_held = false)
 reload_button = _button(root,"RELOAD",Vector2(-295,-200),Vector2(125,65))
 reload_button.pressed.connect(_reload)
 aim_button = _button(root,"AIM",Vector2(-155,-265),Vector2(125,65))
 aim_button.pressed.connect(_toggle_aim)

func _button(parent: Control, label: String, offset: Vector2, dimensions: Vector2) -> Button:
 var b := Button.new()
 b.text = label
 b.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_RIGHT)
 b.position = offset
 b.size = dimensions
 b.add_theme_font_size_override("font_size",23)
 parent.add_child(b)
 return b

func _unhandled_input(event: InputEvent) -> void:
 if not mission_started: return
 if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
  _look(event.relative * MOUSE_SENS)
 if event is InputEventKey and event.pressed and event.keycode == KEY_R: _reload()
 if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_RIGHT and event.pressed: _toggle_aim()
 if event is InputEventKey and event.pressed and event.keycode == KEY_ESCAPE:
  Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
 if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT and not OS.has_feature("mobile"):
  if Input.mouse_mode != Input.MOUSE_MODE_CAPTURED: Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
 if event is InputEventScreenTouch:
  if event.pressed:
   if event.position.x < get_viewport().get_visible_rect().size.x*0.36 and joystick_id == -1:
    joystick_id = event.index
    _update_joystick(event.position)
   elif look_id == -1 and event.position.x < get_viewport().get_visible_rect().size.x*0.73:
    look_id = event.index
    touch_last = event.position
  else:
   if event.index == joystick_id:
    joystick_id = -1
    joystick_vector = Vector2.ZERO
    joy_knob.position = Vector2(55,55)
   if event.index == look_id: look_id = -1
 if event is InputEventScreenDrag:
  if event.index == joystick_id: _update_joystick(event.position)
  elif event.index == look_id:
   _look(event.position - touch_last, TOUCH_SENS)
   touch_last = event.position

func _update_joystick(screen_pos: Vector2) -> void:
 var center := joy_base.global_position + joy_base.size/2.0
 joystick_vector = ((screen_pos-center)/70.0).limit_length(1.0)
 joy_knob.position = Vector2(55,55) + joystick_vector*50.0

func _look(delta: Vector2, sensitivity: float = 1.0) -> void:
 player.rotate_y(-delta.x*sensitivity)
 head.rotation.x = clampf(head.rotation.x-delta.y*sensitivity,-1.35,1.35)

func _jump() -> void:
 if player.is_on_floor(): player.velocity.y = JUMP_SPEED

func _physics_process(delta: float) -> void:
 if not mission_started: return
 patrol_clock += delta
 for enemy in targets:
  if is_instance_valid(enemy):
   var home: Vector3 = enemy.get_meta("patrol_origin")
   var phase: float = enemy.get_meta("patrol_phase")
   var patrol_axis: Vector3 = enemy.get_meta("patrol_axis")
   enemy.position = home + patrol_axis * sin(patrol_clock * 0.65 + phase) * 2.0
 var axis := Input.get_vector("move_left","move_right","move_forward","move_back")
 if joystick_vector.length() > 0.1: axis = joystick_vector
 var dir := player.global_transform.basis * Vector3(axis.x,0,axis.y)
 var speed := RUN_SPEED if sprint_held or Input.is_action_pressed("sprint") else WALK_SPEED
 player.velocity.x = dir.x*speed
 player.velocity.z = dir.z*speed
 if not player.is_on_floor(): player.velocity.y -= 24.0*delta
 if Input.is_action_just_pressed("jump"): _jump()
 player.move_and_slide()
 cooldown = maxf(0,cooldown-delta)
 if reload_timer > 0.0:
  reload_timer -= delta
  if reload_timer <= 0.0: _finish_reload()
 hit_marker_timer = maxf(0.0,hit_marker_timer-delta)
 hit_marker.visible = hit_marker_timer > 0.0
 shot_flash.light_energy = move_toward(shot_flash.light_energy,0.0,delta*45.0)
 camera.fov = move_toward(camera.fov,48.0 if aiming else 75.0,delta*180.0)
 gun.position.z = move_toward(gun.position.z,-0.34 if aiming else 0.0,delta*1.8)
 if fire_held or Input.is_action_pressed("fire"): _shoot()
 recoil = move_toward(recoil,0,delta*3.0)
 gun.position.y = -0.32+recoil
 status.text = "TARGETS %d/12 | HP %d | AMMO %d/%d | XP %d | COINS %d | FPS %d" % [score,health,ammo,reserve_ammo,experience_points,reward_coins,Engine.get_frames_per_second()]

func _shoot() -> void:
 if cooldown > 0 or reload_timer > 0: return
 if ammo <= 0:
  _reload()
  return
 ammo -= 1
 shot_flash.light_energy = 3.5
 cooldown = 0.14
 recoil = -0.05
 var origin := camera.global_position
 var end := origin - camera.global_transform.basis.z*180.0
 var query := PhysicsRayQueryParameters3D.create(origin,end)
 query.exclude = [player.get_rid()]
 var result := get_world_3d().direct_space_state.intersect_ray(query)
 if result.is_empty(): return
 var hit: Object = result.collider
 if hit is StaticBody3D and hit.has_meta("target"):
  hit_marker_timer = 0.14
  var hp: int = hit.get_meta("hit_points") - 1
  hit.set_meta("hit_points",hp)
  if hp <= 0:
   targets.erase(hit)
   hit.queue_free()
   score += 1
   experience_points += 25
   reward_coins += 10

# Egyptian civilian atmosphere: fictional 1942-inspired market set dressing.
func _create_egyptian_life() -> void:
 var mud := material(Color(0.68, 0.51, 0.34))
 var wood := material(Color(0.31, 0.20, 0.12))
 var cloth := material(Color(0.65, 0.18, 0.11))
 var leaf := material(Color(0.20, 0.34, 0.16))
 var road := material(Color(0.49, 0.40, 0.29))
 # Market lane on the edge of the existing training arena.
 box(self, Vector3(-33, 0.01, -17), Vector3(9, 0.05, 46), road, false)
 for i in range(5):
  var z := -35.0 + float(i) * 9.0
  box(self, Vector3(-40, 2.0, z), Vector3(5, 4, 6), mud)
  box(self, Vector3(-37.3, 1.2, z), Vector3(0.3, 2.4, 1.5), wood, false)
  box(self, Vector3(-37.0, 2.6, z), Vector3(3, 0.18, 3), cloth, false)
  box(self, Vector3(-36.8, 0.6, z - 1.2), Vector3(1.4, 1.2, 0.6), wood)
  var sign := Label3D.new()
  sign.text = ["قهوة المحروسة", "بقالة عم سيد", "ورشة أولاد النيل", "عيش بلدي", "سوق البلد"][i]
  sign.font_size = 80
  sign.pixel_size = 0.003
  sign.position = Vector3(-36.9, 3.5, z)
  sign.rotation_degrees.y = 90
  sign.modulate = Color(0.12, 0.08, 0.04)
  sign.no_depth_test = false
  add_child(sign)
 for i in range(7):
  var z := -38.0 + float(i) * 11.0
  box(self, Vector3(-23, 2.2, z), Vector3(0.5, 4.4, 0.5), wood, false)
  for k in range(4):
   var crown := MeshInstance3D.new()
   var sphere := SphereMesh.new()
   sphere.radius = 2.1
   sphere.height = 0.8
   crown.mesh = sphere
   crown.material_override = leaf
   crown.position = Vector3(-23 + cos(float(k) * PI / 2.0) * 1.1, 4.7, z + sin(float(k) * PI / 2.0) * 1.1)
   add_child(crown)
 # A simple Egyptian-style donkey cart silhouette (static prop, no animals).
 box(self, Vector3(-28, 0.9, -6), Vector3(3.1, 0.3, 1.6), wood, false)
 for side in [-1.0, 1.0]:
  var wheel := MeshInstance3D.new()
  var cyl := CylinderMesh.new()
  cyl.top_radius = 0.65
  cyl.bottom_radius = 0.65
  cyl.height = 0.15
  wheel.mesh = cyl
  wheel.material_override = wood
  wheel.rotation_degrees.z = 90
  wheel.position = Vector3(-28, 0.7, -6 + side * 0.85)
  add_child(wheel)


func _create_hero_intro() -> void:
 var layer := CanvasLayer.new()
 layer.layer = 10
 add_child(layer)
 intro_overlay = ColorRect.new()
 intro_overlay.color = Color(0.035,0.055,0.075,0.96)
 intro_overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
 layer.add_child(intro_overlay)
 var layout := HBoxContainer.new()
 layout.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
 layout.add_theme_constant_override("separation", 38)
 layout.offset_left = 65
 layout.offset_right = -65
 layout.offset_top = 55
 layout.offset_bottom = -55
 intro_overlay.add_child(layout)
 var portrait := TextureRect.new()
 portrait.texture = load("res://assets/khaled_portrait.jpg")
 portrait.custom_minimum_size = Vector2(330,440)
 portrait.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
 portrait.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
 layout.add_child(portrait)
 var content := VBoxContainer.new()
 content.size_flags_horizontal = Control.SIZE_EXPAND_FILL
 content.add_theme_constant_override("separation", 20)
 layout.add_child(content)
 var title := Label.new()
 title.text = "WAR FRONT: EGYPT 1942"
 title.add_theme_font_size_override("font_size", 40)
 content.add_child(title)
 var hero := Label.new()
 hero.text = "خالد كارم عبداللا\nKHALED KAREM ABDALLA"
 hero.add_theme_font_size_override("font_size", 32)
 content.add_child(hero)
 var briefing := Label.new()
 briefing.text = "قائد المهمة | العلمين - مصر 1942\nMission briefing: Secure the desert outpost.\nنسخة تجريبية: حركة وتصويب وأهداف ثابتة"
 briefing.add_theme_font_size_override("font_size", 23)
 content.add_child(briefing)
 var start := Button.new()
 start.text = "ابدأ المهمة  |  START MISSION"
 start.custom_minimum_size = Vector2(420,82)
 start.add_theme_font_size_override("font_size", 28)
 content.add_child(start)
 start.pressed.connect(_start_hero_mission)

func _start_hero_mission() -> void:
 mission_started = true
 intro_overlay.visible = false
 if not OS.has_feature("mobile"):
  Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
